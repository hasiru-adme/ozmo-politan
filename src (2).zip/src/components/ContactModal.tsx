"use client";

import { useState } from "react";
import { X } from "lucide-react";

export default function ContactModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [message, setMessage] = useState("");
  const [hpField, setHpField] = useState(""); // honeypot — stays empty for real users
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [errorMsg, setErrorMsg] = useState("");

  if (!open) return null;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("loading");
    setErrorMsg("");

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, phone, message, hpField }),
      });

      const data = await res.json();

      if (!res.ok) {
        setErrorMsg(data.error || "Something went wrong");
        setStatus("error");
        return;
      }

      setStatus("success");
      setName(""); setEmail(""); setPhone(""); setMessage("");
    } catch {
      setErrorMsg("Network error — please try again");
      setStatus("error");
    }
  }

  return (
    <div className="fixed inset-0 z-100 flex items-center justify-center p-4 bg-black/50" onClick={onClose}>
      <div
        className="w-full max-w-md bg-white rounded-2xl p-7 relative shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 transition">
          <X size={20} />
        </button>

        {status === "success" ? (
          <div className="text-center py-6">
            <div className="w-14 h-14 rounded-full bg-sage-light mx-auto mb-4 grid place-items-center text-sage-dark text-2xl">✓</div>
            <h3 className="text-xl font-semibold mb-2">Message sent</h3>
            <p className="text-sm text-gray-500">We&apos;ll get back to you within one business day.</p>
            <button onClick={onClose} className="mt-6 bg-black text-white text-sm font-medium px-5 py-2.5 rounded-full">
              Close
            </button>
          </div>
        ) : (
          <>
            <h3 className="text-xl font-semibold mb-1">Let&apos;s talk about your business</h3>
            <p className="text-sm text-gray-500 mb-6">Tell us what&apos;s slowing you down — no pressure, no tech jargon.</p>

            <form onSubmit={handleSubmit} className="flex flex-col gap-3">
              {/* Honeypot — hidden from real users, not a common autofill-triggering name */}
              <div aria-hidden="true" style={{ position: "absolute", left: "-9999px", top: "-9999px", height: 0, overflow: "hidden" }}>
                <input
                  type="text"
                  name="hp_field_x9"
                  value={hpField}
                  onChange={(e) => setHpField(e.target.value)}
                  tabIndex={-1}
                  autoComplete="off"
                />
              </div>

              <input
                placeholder="Your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                maxLength={100}
                className="border border-line rounded-lg px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-accent/40 focus:border-accent transition"
              />
              <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                maxLength={150}
                className="border border-line rounded-lg px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-accent/40 focus:border-accent transition"
              />
              <input
                type="tel"
                placeholder="Phone (optional)"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                maxLength={30}
                className="border border-line rounded-lg px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-accent/40 focus:border-accent transition"
              />
              <textarea
                placeholder="What's slowing your business down?"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
                maxLength={2000}
                rows={4}
                className="border border-line rounded-lg px-3.5 py-2.5 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-accent/40 focus:border-accent transition"
              />

              {status === "error" && <p className="text-sm text-red-500">{errorMsg}</p>}

              <button
                type="submit"
                disabled={status === "loading"}
                className="bg-accent hover:bg-[#e9aa0e] disabled:opacity-60 text-sm font-bold py-3 rounded-full transition mt-2"
              >
                {status === "loading" ? "Sending..." : "Send message"}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}