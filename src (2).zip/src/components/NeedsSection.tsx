"use client";

import { motion, useInView } from "framer-motion";
import { useRef, useState } from "react";
import {
  Globe2,
  Zap,
  Bot,
  BarChart3,
  ArrowUpRight,
  Check,
} from "lucide-react";

const needs = [
  {
    number: "01",
    title: "Get online",
    problem: "Your business needs a stronger digital presence.",
    solution: "Website · E-commerce · Landing page",
    Icon: Globe2,
  },
  {
    number: "02",
    title: "Save time",
    problem: "Too much manual work is slowing your business down.",
    solution: "Automation · Integrations · Workflows",
    Icon: Zap,
  },
  {
    number: "03",
    title: "Use AI",
    problem: "You know AI can help, but don't know where to start.",
    solution: "AI assistants · Support · Smart tools",
    Icon: Bot,
  },
  {
    number: "04",
    title: "Grow",
    problem: "You need more leads, visibility and measurable results.",
    solution: "SEO · Analytics · Lead generation",
    Icon: BarChart3,
  },
];

const ease = [0.22, 1, 0.36, 1] as const;

/* --------------------------------
   BLOCK REVEAL
-------------------------------- */

function Reveal({
  children,
  delay = 0,
}: {
  children: React.ReactNode;
  delay?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);

  const inView = useInView(ref, {
    amount: 0.15,
    margin: "0px 0px -80px 0px",
    once: false,
  });

  return (
    <motion.div
      ref={ref}
      initial={{
        opacity: 0,
        y: 30,
      }}
      animate={
        inView
          ? {
              opacity: 1,
              y: 0,
            }
          : {
              opacity: 0,
              y: 30,
            }
      }
      transition={{
        duration: 0.7,
        delay: inView ? delay : 0,
        ease,
      }}
    >
      {children}
    </motion.div>
  );
}

/* --------------------------------
   WORD BY WORD TEXT
-------------------------------- */

function AnimatedWords({
  children,
  className = "",
  delay = 0,
  stagger = 0.055,
}: {
  children: string;
  className?: string;
  delay?: number;
  stagger?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);

  const inView = useInView(ref, {
    amount: 0.4,
    once: false,
  });

  const words = children.split(" ");

  return (
    <div ref={ref} className={className}>
      {words.map((word, index) => (
        <motion.span
          key={`${word}-${index}`}
          className="inline-block mr-[0.22em]"
          initial={{
            opacity: 0,
            y: 22,
            filter: "blur(7px)",
          }}
          animate={
            inView
              ? {
                  opacity: 1,
                  y: 0,
                  filter: "blur(0px)",
                }
              : {
                  opacity: 0,
                  y: 22,
                  filter: "blur(7px)",
                }
          }
          transition={{
            duration: 0.65,
            delay: inView ? delay + index * stagger : 0,
            ease,
          }}
        >
          {word}
        </motion.span>
      ))}
    </div>
  );
}

/* --------------------------------
   CARD TEXT
-------------------------------- */

function CardText({
  children,
  className = "",
  delay = 0,
}: {
  children: string;
  className?: string;
  delay?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);

  const inView = useInView(ref, {
    amount: 0.5,
    once: false,
  });

  const words = children.split(" ");

  return (
    <div ref={ref} className={className}>
      {words.map((word, index) => (
        <motion.span
          key={`${word}-${index}`}
          className="inline-block mr-[0.2em]"
          initial={{
            opacity: 0,
            y: 10,
          }}
          animate={
            inView
              ? {
                  opacity: 1,
                  y: 0,
                }
              : {
                  opacity: 0,
                  y: 10,
                }
          }
          transition={{
            duration: 0.4,
            delay: inView ? delay + index * 0.025 : 0,
            ease,
          }}
        >
          {word}
        </motion.span>
      ))}
    </div>
  );
}

/* --------------------------------
   MAIN
-------------------------------- */

export default function NeedsSection() {
  const [selected, setSelected] = useState<string | null>(null);

  return (
    <section
      id="needs"
      className="relative overflow-hidden bg-white px-[5vw] py-[100px] md:px-[6vw] md:py-[140px]"
    >
      <div className="relative z-10 mx-auto max-w-[1500px]">

        {/* ================= HEADER ================= */}

        <Reveal>
          <div className="mb-5 flex items-center gap-2.5 text-[10px] font-bold uppercase tracking-[0.14em] text-gray-500">
            <motion.span
              initial={{ width: 0 }}
              whileInView={{ width: 20 }}
              viewport={{ once: false }}
              transition={{
                duration: 0.6,
                ease,
              }}
              className="block h-[2px] bg-accent"
            />

            <motion.span
              initial={{
                opacity: 0,
                x: -10,
              }}
              whileInView={{
                opacity: 1,
                x: 0,
              }}
              viewport={{ once: false }}
              transition={{
                duration: 0.5,
                delay: 0.15,
                ease,
              }}
            >
              Start with your problem
            </motion.span>
          </div>

          {/* Main heading */}
          <div className="max-w-[900px]">
            <AnimatedWords
              delay={0.1}
              stagger={0.065}
              className="text-[clamp(40px,5vw,72px)] font-normal leading-[0.98] tracking-[-0.04em] text-gray-900"
            >
              What does your business
            </AnimatedWords>

            <AnimatedWords
              delay={0.42}
              stagger={0.07}
              className="text-[clamp(40px,5vw,72px)] font-normal leading-[0.98] tracking-[-0.04em] text-gray-400"
            >
              need right now?
            </AnimatedWords>

            {/* Description */}
            <AnimatedWords
              delay={0.72}
              stagger={0.025}
              className="mt-7 max-w-[560px] text-[14px] leading-[1.7] text-gray-500 md:text-[15px]"
            >
              You don't need to understand the technology. Just tell us what is making your business harder. We'll help you find the right solution.
            </AnimatedWords>
          </div>
        </Reveal>

        {/* ================= CARDS ================= */}

        <div className="mt-16 grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
          {needs.map(
            (
              {
                number,
                title,
                problem,
                solution,
                Icon,
              },
              i
            ) => {
              const isSelected = selected === number;
              const hasSelection = selected !== null;

              return (
                <Reveal
                  key={number}
                  delay={i * 0.08}
                >
                  <motion.button
                    type="button"
                    onClick={() =>
                      setSelected(
                        isSelected ? null : number
                      )
                    }
                    animate={{
                      opacity:
                        hasSelection && !isSelected
                          ? 0.42
                          : 1,
                      y: isSelected ? -8 : 0,
                    }}
                    whileHover={{
                      y: -8,
                    }}
                    whileTap={{
                      scale: 0.985,
                    }}
                    transition={{
                      duration: 0.4,
                      ease,
                    }}
                    className={`
                      group relative flex min-h-[390px]
                      w-full flex-col overflow-hidden
                      rounded-[28px]
                      border
                      p-7
                      text-left
                      outline-none
                      transition-[background,border-color,box-shadow]
                      duration-500
                      focus-visible:ring-2
                      focus-visible:ring-accent

                      ${
                        isSelected
                          ? "border-gray-900 bg-gray-900 text-white shadow-[0_30px_80px_rgba(0,0,0,0.16)]"
                          : "border-gray-200 bg-[#fafaf8] hover:border-gray-900 hover:bg-gray-900 hover:text-white"
                      }
                    `}
                  >
                    {/* Selected line */}

                    <motion.div
                      initial={false}
                      animate={{
                        scaleX: isSelected ? 1 : 0,
                        opacity: isSelected ? 1 : 0,
                      }}
                      transition={{
                        duration: 0.45,
                        ease,
                      }}
                      className="absolute left-0 right-0 top-0 h-[3px] origin-left bg-accent"
                    />

                    {/* Top */}

                    <div className="flex items-start justify-between">
                      <motion.span
                        animate={{
                          y: isSelected ? -2 : 0,
                        }}
                        className={`
                          text-[11px]
                          font-bold
                          tracking-[0.12em]
                          transition-colors
                          duration-500

                          ${
                            isSelected
                              ? "text-accent"
                              : "text-gray-400 group-hover:text-accent"
                          }
                        `}
                      >
                        {/* {number} */}
                      </motion.span>

                      <motion.div
                        animate={{
                          rotate: isSelected
                            ? -10
                            : 0,
                          scale: isSelected
                            ? 1.08
                            : 1,
                        }}
                        transition={{
                          duration: 0.4,
                          ease,
                        }}
                        className={`
                          flex h-12 w-12
                          items-center justify-center
                          rounded-full
                          border
                          transition-colors
                          duration-500

                          ${
                            isSelected
                              ? "border-white/15 bg-white/10"
                              : "border-gray-200 bg-white group-hover:border-white/15 group-hover:bg-white/10"
                          }
                        `}
                      >
                        <Icon
                          size={21}
                          strokeWidth={1.7}
                          className={`
                            transition-colors
                            duration-500

                            ${
                              isSelected
                                ? "text-white"
                                : "text-gray-700 group-hover:text-white"
                            }
                          `}
                        />
                      </motion.div>
                    </div>

                    {/* Divider */}

                    <motion.div
                      animate={{
                        scaleX: isSelected
                          ? 1
                          : 0.65,
                      }}
                      transition={{
                        duration: 0.5,
                        ease,
                      }}
                      className={`
                        mt-10 h-px
                        origin-left
                        transition-colors
                        duration-500

                        ${
                          isSelected
                            ? "bg-white/10"
                            : "bg-gray-200 group-hover:bg-white/10"
                        }
                      `}
                    />

                    {/* Content */}

                    <div className="mt-8">

                      {/* Card title */}

                      <CardText
                        delay={0.05}
                        className={`
                          text-[30px]
                          font-medium
                          leading-none
                          tracking-[-0.04em]
                          transition-colors
                          duration-500

                          ${
                            isSelected
                              ? "text-white"
                              : "text-gray-900 group-hover:text-white"
                          }
                        `}
                      >
                        {title}
                      </CardText>

                      {/* Problem */}

                      <CardText
                        delay={0.18}
                        className={`
                          mt-5
                          max-w-[245px]
                          text-[13px]
                          leading-[1.65]
                          transition-colors
                          duration-500

                          ${
                            isSelected
                              ? "text-gray-400"
                              : "text-gray-500 group-hover:text-gray-400"
                          }
                        `}
                      >
                        {problem}
                      </CardText>
                    </div>

                    {/* Bottom */}

                    <div className="mt-auto">

                      {/* Solution */}

                      <CardText
                        delay={0.28}
                        className={`
                          mb-5
                          text-[10px]
                          font-bold
                          uppercase
                          leading-[1.5]
                          tracking-[0.08em]
                          transition-colors
                          duration-500

                          ${
                            isSelected
                              ? "text-accent"
                              : "text-gray-400 group-hover:text-accent"
                          }
                        `}
                      >
                        {solution}
                      </CardText>

                      {/* CTA */}

                      <div
                        className={`
                          flex
                          items-center
                          justify-between
                          border-t
                          pt-5
                          transition-colors
                          duration-500

                          ${
                            isSelected
                              ? "border-white/10"
                              : "border-gray-200 group-hover:border-white/10"
                          }
                        `}
                      >
                        <motion.span
                          initial={false}
                          animate={{
                            x: isSelected ? 3 : 0,
                          }}
                          className={`
                            text-[10px]
                            font-bold
                            uppercase
                            tracking-[0.12em]
                            transition-colors
                            duration-500

                            ${
                              isSelected
                                ? "text-white"
                                : "text-gray-700 group-hover:text-white"
                            }
                          `}
                        >
                          {isSelected
                            ? "Let's solve this"
                            : "Explore solution"}
                        </motion.span>

                        <motion.span
                          animate={{
                            x: isSelected ? 4 : 0,
                            y: isSelected ? -4 : 0,
                          }}
                          transition={{
                            duration: 0.35,
                            ease,
                          }}
                          className={`
                            flex h-9 w-9
                            items-center justify-center
                            rounded-full
                            border
                            transition-colors
                            duration-500

                            ${
                              isSelected
                                ? "border-white bg-white"
                                : "border-gray-200 bg-white group-hover:border-white"
                            }
                          `}
                        >
                          {isSelected ? (
                            <Check
                              size={15}
                              className="text-gray-900"
                            />
                          ) : (
                            <ArrowUpRight
                              size={16}
                              className="text-gray-700 group-hover:text-gray-900"
                            />
                          )}
                        </motion.span>
                      </div>
                    </div>

                    {/* Glow */}

                    <motion.div
                      animate={{
                        opacity: isSelected
                          ? 1
                          : 0,
                        scale: isSelected
                          ? 1.2
                          : 1,
                      }}
                      transition={{
                        duration: 0.7,
                        ease,
                      }}
                      className="pointer-events-none absolute -bottom-24 -right-24 h-56 w-56 rounded-full bg-accent/[0.07] blur-3xl"
                    />
                  </motion.button>
                </Reveal>
              );
            }
          )}
        </div>

        {/* ================= SELECTED MESSAGE ================= */}

        <motion.div
          initial={false}
          animate={{
            height: selected ? "auto" : 0,
            opacity: selected ? 1 : 0,
            marginTop: selected ? 32 : 0,
          }}
          className="overflow-hidden"
        >
          <div className="rounded-[20px] border border-gray-200 bg-[#fafaf8] p-5 sm:px-6">
            <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">

              <div>
                <AnimatedWords
                  delay={0.05}
                  stagger={0.035}
                  className="text-[10px] font-bold uppercase tracking-[0.14em] text-accent"
                >
                  Your starting point
                </AnimatedWords>

                <AnimatedWords
                  delay={0.18}
                  stagger={0.02}
                  className="mt-2 max-w-[650px] text-[14px] leading-[1.6] text-gray-600"
                >
                  Tell us more about this challenge and we'll map out the right digital solution for your business.
                </AnimatedWords>
              </div>

              <a
                href="#contact"
                className="group inline-flex shrink-0 items-center gap-3 text-[11px] font-bold uppercase tracking-[0.12em] text-gray-900"
              >
                Continue

                <span className="grid h-9 w-9 place-items-center rounded-full bg-gray-900 text-white transition-transform duration-300 group-hover:translate-x-1">
                  <ArrowUpRight size={15} />
                </span>
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}