"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import {
  Globe2,
  MessageSquare,
  Database,
  Bot,
  Phone,
  CalendarDays,
  Mail,
  Code2,
  Check,
  CircleCheck,
  ArrowRight,
} from "lucide-react";

const caseSteps = [
  {
    text: "A customer visits your website.",
    Icon: Globe2,
    img: "/images/case/website.jpg",
    tint: "#dfeaf5",
    tintInk: "#46627b",
  },
  {
    text: "They request a quote.",
    Icon: MessageSquare,
    img: "/images/case/quote.jpg",
    tint: "#f5e7d7",
    tintInk: "#9b673b",
  },
  {
    text: "The request is automatically captured.",
    Icon: Database,
    img: "/images/case/captured.jpg",
    tint: "#f2dfdf",
    tintInk: "#985959",
  },
  {
    text: "AI helps qualify the enquiry.",
    Icon: Bot,
    img: "/images/case/ai.jpg",
    tint: "#e8e2f1",
    tintInk: "#6d5b82",
  },
  {
    text: "Your team gets notified.",
    Icon: Phone,
    img: "/images/case/notified.jpg",
    tint: "#dfeadf",
    tintInk: "#557255",
  },
  {
    text: "Customer books a time.",
    Icon: CalendarDays,
    img: "/images/case/booking.jpg",
    tint: "#dceaea",
    tintInk: "#4f7070",
  },
  {
    text: "Reminder is sent automatically.",
    Icon: Mail,
    img: "/images/case/reminder.jpg",
    tint: "#dfeaf5",
    tintInk: "#46627b",
  },
  {
    text: "Invoice is created.",
    Icon: Code2,
    img: "/images/case/invoice.jpg",
    tint: "#f5e7d7",
    tintInk: "#9b673b",
  },
  {
    text: "Payment is received.",
    Icon: Check,
    img: "/images/case/payment.jpg",
    tint: "#f2dfdf",
    tintInk: "#985959",
  },
  {
    text: "Customer gets a review request.",
    Icon: CircleCheck,
    img: "/images/case/review.jpg",
    tint: "#dfeadf",
    tintInk: "#557255",
  },
];

const ease = [0.22, 1, 0.36, 1] as const;

/* ---------------------------------
   WORD BY WORD ANIMATION
---------------------------------- */

function AnimatedWords({
  text,
  delay = 0,
  className = "",
  duration = 0.5,
  stagger = 0.045,
}: {
  text: string;
  delay?: number;
  className?: string;
  duration?: number;
  stagger?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);

  const inView = useInView(ref, {
    amount: 0.25,
    once: false,
  });

  const words = text.split(" ");

  return (
    <div ref={ref} className={className}>
      {words.map((word, index) => (
        <motion.span
          key={`${word}-${index}`}
          className="mr-[0.25em] inline-block"
          initial={{
            opacity: 0,
            y: 16,
            filter: "blur(4px)",
          }}
          animate={
            inView
              ? {
                  opacity: 1,
                  y: 0,
                  filter: "blur(0px)",
                }
              : {
                  opacity: 0,
                  y: 16,
                  filter: "blur(4px)",
                }
          }
          transition={{
            duration,
            delay: inView ? delay + index * stagger : 0,
            ease,
          }}
        >
          {word}
        </motion.span>
      ))}
    </div>
  );
}

/* ---------------------------------
   REVEAL
---------------------------------- */

function Reveal({
  children,
  delay = 0,
  className = "",
}: {
  children: React.ReactNode;
  delay?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);

  const inView = useInView(ref, {
    amount: 0.15,
    margin: "0px 0px -80px 0px",
    once: false,
  });

  return (
    <motion.div
      ref={ref}
      className={className}
      initial={{
        opacity: 0,
        y: 28,
      }}
      animate={
        inView
          ? {
              opacity: 1,
              y: 0,
            }
          : {
              opacity: 0,
              y: 28,
            }
      }
      transition={{
        duration: 0.7,
        delay: inView ? delay : 0,
        ease,
      }}
    >
      {children}
    </motion.div>
  );
}

/* ---------------------------------
   CASE SECTION
---------------------------------- */

export default function CaseSection() {
  return (
    <section
      id="case"
      className="relative overflow-hidden bg-white px-5 py-16 sm:px-[5vw] sm:py-[90px] md:px-[6vw] md:py-[125px]"
    >
      {/* =================================
          AMBIENT BACKGROUND
      ================================= */}

      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute left-1/2 top-[12%] h-[320px] w-[520px] -translate-x-1/2 rounded-full bg-accent/[0.035] blur-[130px]" />
      </div>

      <div className="relative mx-auto max-w-[1450px]">

        {/* =================================
            HEADER
        ================================= */}

        <div className="max-w-[850px]">

          {/* Label */}
          <Reveal>
            <motion.div
              initial={{
                opacity: 0,
                x: -15,
              }}
              whileInView={{
                opacity: 1,
                x: 0,
              }}
              viewport={{
                once: false,
              }}
              transition={{
                duration: 0.6,
                ease,
              }}
              className="mb-5 flex items-center gap-2.5 text-[10px] font-bold uppercase tracking-[0.14em] text-gray-500"
            >
              <motion.span
                initial={{
                  width: 0,
                }}
                whileInView={{
                  width: 20,
                }}
                viewport={{
                  once: false,
                }}
                transition={{
                  duration: 0.5,
                  ease,
                }}
                className="block h-[2px] bg-accent"
              />

              <span>Real-life example</span>
            </motion.div>
          </Reveal>

          {/* Heading */}
          <AnimatedWords
            text="Imagine you run"
            delay={0.05}
            stagger={0.07}
            duration={0.6}
            className="text-[clamp(38px,5vw,72px)] font-normal leading-[0.98] tracking-[-0.045em]"
          />

          <AnimatedWords
            text="a cleaning business."
            delay={0.18}
            stagger={0.07}
            duration={0.6}
            className="text-[clamp(38px,5vw,72px)] font-normal leading-[0.98] tracking-[-0.045em] text-gray-500"
          />

          {/* Supporting text */}
          <AnimatedWords
            text="Here's what happens when the right digital systems work together."
            delay={0.18}
            stagger={0.03}
            duration={0.45}
            className="mt-6 max-w-[560px] text-[15px] leading-[1.7] text-gray-500 md:text-[17px]"
          />
        </div>

        {/* =================================
            WORKFLOW
        ================================= */}

        <div className="relative mt-14 sm:mt-16 md:mt-20">

          {/* Desktop base line */}
          <div className="pointer-events-none absolute left-[5%] right-[5%] top-[45px] hidden h-px bg-[#deded8] lg:block" />

          {/* Animated line */}
          <motion.div
            initial={{
              scaleX: 0,
            }}
            whileInView={{
              scaleX: 1,
            }}
            viewport={{
              once: false,
              amount: 0.2,
            }}
            transition={{
              duration: 1.8,
              delay: 0.2,
              ease,
            }}
            className="pointer-events-none absolute left-[5%] right-[5%] top-[45px] hidden h-px origin-left bg-accent/40 lg:block"
          />

          {/* Mobile line */}
          <div className="pointer-events-none absolute bottom-[40px] left-[25px] top-[40px] w-px bg-[#deded8] lg:hidden" />

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 lg:gap-0">

            {caseSteps.map(
              ({ text, Icon, img, tint, tintInk }, i) => (
                <Reveal key={text} delay={i * 0.055}>

                  {/* =================================
                      CARD
                  ================================= */}

                  <motion.div
                    whileHover={{
                      y: -7,
                    }}
                    transition={{
                      duration: 0.3,
                      ease,
                    }}
                    className="
                      group
                      relative
                      isolate
                      min-h-[270px]
                      overflow-hidden
                      rounded-2xl
                      border
                      border-[#deded8]
                      bg-[#f0f0eb]
                      lg:rounded-none
                      lg:border-0
                      lg:border-r
                      lg:border-[#deded8]
                      lg:last:border-r-0
                    "
                  >

                    {/* =================================
                        IMAGE
                    ================================= */}

                    <div
                      className="
                        absolute
                        inset-0
                        -z-30
                        bg-cover
                        bg-center
                        scale-[1.06]
                        opacity-[0.80]
                        transition-all
                        duration-700
                        ease-out
                        group-hover:scale-100
                        group-hover:opacity-100
                      "
                      style={{
                        backgroundImage: `url(${img})`,
                      }}
                    />

                    {/* =================================
                        IMAGE GRADIENT
                    ================================= */}

                    <div
                      className="
                        absolute
                        inset-0
                        -z-20
                        bg-gradient-to-t
                        from-white
                        via-white/80
                        to-white/45
                        transition-all
                        duration-700
                        group-hover:from-black/35
                        group-hover:via-black/10
                        group-hover:to-transparent
                      "
                    />

                    {/* =================================
                        HOVER IMAGE OVERLAY
                    ================================= */}

                    <div
                      className="
                        absolute
                        inset-0
                        -z-10
                        bg-black/0
                        transition-colors
                        duration-500
                        group-hover:bg-black/10
                      "
                    />

                    {/* =================================
                        SUBTLE COLOR TINT
                    ================================= */}

                    <div
                      className="
                        pointer-events-none
                        absolute
                        inset-0
                        -z-[5]
                        opacity-0
                        transition-opacity
                        duration-500
                        group-hover:opacity-[0.12]
                      "
                      style={{
                        backgroundColor: tint,
                      }}
                    />

                    {/* =================================
                        CONTENT
                    ================================= */}

                    <div className="relative flex min-h-[270px] flex-col justify-between p-5 sm:p-6">

                      {/* ICON */}

                      <motion.div
                        className="
                          grid
                          h-11
                          w-11
                          shrink-0
                          place-items-center
                          rounded-full
                          bg-white
                          shadow-[0_8px_25px_rgba(0,0,0,0.08)]
                          transition-all
                          duration-500
                          group-hover:scale-105
                          group-hover:shadow-[0_12px_30px_rgba(0,0,0,0.16)]
                        "
                      >
                        <Icon
                          size={19}
                          style={{
                            color: tintInk,
                          }}
                        />
                      </motion.div>

                      {/* =================================
                          TEXT PANEL
                      ================================= */}

                      <div
                        className="
                          mt-8
                          rounded-xl
                          border
                          border-white/70
                          bg-white/90
                          p-4
                          backdrop-blur-md
                          transition-all
                          duration-500
                          group-hover:border-white/20
                          group-hover:bg-white/80
                        "
                      >

                        <AnimatedWords
                          text={text}
                          delay={0.08}
                          stagger={0.025}
                          duration={0.42}
                          className="
                            text-[13px]
                            font-semibold
                            leading-[1.45]
                            text-gray-800
                            transition-colors
                            duration-500
                            group-hover:text-gray-950
                          "
                        />

                        {/* Hover CTA */}

                        <div
                          className="
                            mt-3
                            flex
                            items-center
                            gap-1.5
                            overflow-hidden
                            text-[10px]
                            font-bold
                            uppercase
                            tracking-[0.12em]
                            text-gray-500
                            opacity-0
                            -translate-x-2
                            transition-all
                            duration-500
                            group-hover:translate-x-0
                            group-hover:opacity-100
                          "
                        >
                          <span>See how it works</span>

                          <ArrowRight
                            size={13}
                            className="
                              transition-transform
                              duration-300
                              group-hover:translate-x-1
                            "
                          />
                        </div>
                      </div>

                      {/* =================================
                          BOTTOM ACCENT
                      ================================= */}

                      <span
                        className="
                          absolute
                          bottom-0
                          left-0
                          right-0
                          h-[3px]
                          origin-left
                          scale-x-0
                          transition-transform
                          duration-500
                          ease-out
                          group-hover:scale-x-100
                        "
                        style={{
                          backgroundColor: tintInk,
                        }}
                      />
                    </div>
                  </motion.div>
                </Reveal>
              )
            )}
          </div>
        </div>

        {/* =================================
            RESULT
        ================================= */}

        <Reveal delay={0.2}>
          <div className="mt-16 border-t border-[#deded8] pt-12 text-center sm:mt-[90px]">

            <AnimatedWords
              text="That's not just a website."
              delay={0.05}
              stagger={0.05}
              duration={0.5}
              className="text-[15px] text-gray-500 md:text-[17px]"
            />

            <AnimatedWords
              text="That's a digital business system."
              delay={0.16}
              stagger={0.06}
              duration={0.55}
              className="mt-2 text-[clamp(32px,5vw,66px)] leading-[1.05] tracking-[-0.04em]"
            />

            <motion.div
              initial={{
                width: 0,
                opacity: 0,
              }}
              whileInView={{
                width: 80,
                opacity: 1,
              }}
              viewport={{
                once: false,
              }}
              transition={{
                duration: 0.7,
                delay: 0.45,
                ease,
              }}
              className="mx-auto mt-6 h-[2px] bg-accent"
            />
          </div>
        </Reveal>
      </div>
    </section>
  );
}