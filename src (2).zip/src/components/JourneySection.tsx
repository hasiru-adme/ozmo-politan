"use client";

import {
  motion,
  useInView,
  useScroll,
  useSpring,
  useMotionValueEvent,
  AnimatePresence,
} from "framer-motion";
import { useEffect, useRef, useState, useCallback } from "react";
import {
  Globe2,
  Workflow,
  Bot,
  Link2,
  BarChart3,
  Rocket,
  ArrowRight,
} from "lucide-react";

/* ------------------------------------------------------------------ */
/* CONFIG                                                              */
/* ------------------------------------------------------------------ */

const TOTAL_FRAMES = 60;

// Each card starts at this frame index (0-based). Adjust to match your video.
// Example: Build 0-9, Automate 10-19, AI 20-29 ...
const CARD_START_FRAMES = [0, 10, 20, 30, 40, 50];

const FIRST_BATCH = 10; // frames loaded first (loader waits for these)

const framePath = (i: number, mobile: boolean) =>
  `/journey-frames/${mobile ? "mobile/" : ""}frame_${String(i + 1).padStart(3, "0")}.webp`;

const journey = [
  { n: "01", title: "Build", text: "We create the website, app or platform your business needs.", Icon: Globe2 },
  { n: "02", title: "Automate", text: "Repetitive tasks become automated workflows.", Icon: Workflow },
  { n: "03", title: "AI", text: "AI helps your team respond, understand and work faster.", Icon: Bot },
  { n: "04", title: "Integrate", text: "Your tools work together instead of working separately.", Icon: Link2 },
  { n: "05", title: "Understand", text: "Turn your business data into simple, useful dashboards.", Icon: BarChart3 },
  { n: "06", title: "Grow", text: "Improve your digital presence and turn more visitors into customers.", Icon: Rocket },
];

/* ------------------------------------------------------------------ */
/* SMALL HELPERS                                                       */
/* ------------------------------------------------------------------ */

function Reveal({
  children,
  delay = 0,
}: {
  children: React.ReactNode;
  delay?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, {
    amount: 0.15,
    margin: "0px 0px -80px 0px",
    once: false,
  });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 35, filter: "blur(8px)" }}
      animate={
        inView
          ? { opacity: 1, y: 0, filter: "blur(0px)" }
          : { opacity: 0, y: 35, filter: "blur(8px)" }
      }
      transition={{
        duration: 0.7,
        delay: inView ? delay : 0,
        ease: [0.22, 1, 0.36, 1],
      }}
    >
      {children}
    </motion.div>
  );
}

function AnimatedWords({ text, delay = 0 }: { text: string; delay?: number }) {
  return (
    <span className="inline-flex flex-wrap gap-x-[0.22em]">
      {text.split(" ").map((word, index) => (
        <motion.span
          key={`${word}-${index}`}
          initial={{ opacity: 0, y: 30, filter: "blur(8px)" }}
          whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          viewport={{ once: false, amount: 0.5 }}
          transition={{
            duration: 0.55,
            delay: delay + index * 0.055,
            ease: [0.22, 1, 0.36, 1],
          }}
          className="inline-block"
        >
          {word}
        </motion.span>
      ))}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* SCROLL FRAME STAGE                                                  */
/* ------------------------------------------------------------------ */

function FrameStage() {
  const trackRef = useRef<HTMLDivElement>(null); // tall scroll container
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imagesRef = useRef<(HTMLImageElement | null)[]>(
    Array(TOTAL_FRAMES).fill(null)
  );
  const frameRef = useRef(0);
  const rafRef = useRef<number | null>(null);

  const [loaded, setLoaded] = useState(0);
  const [ready, setReady] = useState(false);
  const [active, setActive] = useState(0);

  /* ---------- draw (object-fit: cover) ---------- */
  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // find the nearest loaded frame (going backwards) if exact one isn't ready
    let i = frameRef.current;
    while (i > 0 && !imagesRef.current[i]) i--;
    const img = imagesRef.current[i];
    if (!img) return;

    const cw = canvas.width;
    const ch = canvas.height;
    const scale = Math.max(cw / img.naturalWidth, ch / img.naturalHeight);
    const w = img.naturalWidth * scale;
    const h = img.naturalHeight * scale;
    ctx.clearRect(0, 0, cw, ch);
    ctx.drawImage(img, (cw - w) / 2, (ch - h) / 2, w, h);
  }, []);

  const scheduleDraw = useCallback(() => {
    if (rafRef.current !== null) return;
    rafRef.current = requestAnimationFrame(() => {
      rafRef.current = null;
      draw();
    });
  }, [draw]);

  /* ---------- canvas resize (DPR aware) ---------- */
  useEffect(() => {
    const resize = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = canvas.clientWidth * dpr;
      canvas.height = canvas.clientHeight * dpr;
      draw();
    };
    resize();
    window.addEventListener("resize", resize);
    return () => window.removeEventListener("resize", resize);
  }, [draw]);

  /* ---------- preload frames ---------- */
  useEffect(() => {
    const mobile = window.innerWidth < 768;
    let cancelled = false;
    let count = 0;

    const load = (i: number) =>
      new Promise<void>((resolve) => {
        const img = new Image();
        img.decoding = "async";
        img.onload = () => {
          if (cancelled) return resolve();
          imagesRef.current[i] = img;
          count++;
          setLoaded(count);
          if (i === 0) draw();
          resolve();
        };
        img.onerror = () => resolve();
        img.src = framePath(i, mobile);
      });

    (async () => {
      // 1) first batch
      await Promise.all(
        Array.from({ length: FIRST_BATCH }, (_, i) => load(i))
      );
      if (cancelled) return;
      setReady(true);
      draw();

      // 2) the rest, in small chunks so we don't choke the network
      const rest = Array.from(
        { length: TOTAL_FRAMES - FIRST_BATCH },
        (_, i) => i + FIRST_BATCH
      );
      for (let k = 0; k < rest.length; k += 6) {
        if (cancelled) return;
        await Promise.all(rest.slice(k, k + 6).map(load));
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [draw]);

  /* ---------- scroll -> spring -> frame ---------- */
  const { scrollYProgress } = useScroll({
    target: trackRef,
    offset: ["start start", "end end"],
  });

  const smooth = useSpring(scrollYProgress, {
    stiffness: 120,
    damping: 30,
    mass: 0.35,
  });

  useMotionValueEvent(smooth, "change", (v) => {
    const clamped = Math.min(Math.max(v, 0), 1);
    const idx = Math.round(clamped * (TOTAL_FRAMES - 1));

    if (idx !== frameRef.current) {
      frameRef.current = idx;
      scheduleDraw();
    }

    // active card (state only changes when the card changes)
    let a = 0;
    for (let i = 0; i < CARD_START_FRAMES.length; i++) {
      if (idx >= CARD_START_FRAMES[i]) a = i;
    }
    setActive((prev) => (prev === a ? prev : a));
  });

  const current = journey[active];
  const Icon = current.Icon;
  const percent = Math.round((loaded / TOTAL_FRAMES) * 100);

  return (
    <div
      id="solutions"
      ref={trackRef}
      className="relative mt-16 h-[350vh] md:h-[500vh]"
    >
      {/* STICKY STAGE */}
      <div className="sticky top-0 h-screen py-4 md:py-6">
        <div className="relative h-full w-full overflow-hidden rounded-[22px] md:rounded-[28px] border border-white/10 bg-[#151515] shadow-[0_15px_40px_rgba(0,0,0,0.08)]">
          {/* CANVAS */}
          <canvas
            ref={canvasRef}
            className="absolute inset-0 h-full w-full"
          />

          {/* OVERLAY */}
          <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(5,5,5,0.35)_0%,rgba(5,5,5,0.5)_45%,rgba(5,5,5,0.92)_100%)]" />

          {/* GOLD GLOW */}
          <div className="absolute w-[380px] h-[380px] -right-[140px] -bottom-[140px] rounded-full bg-[radial-gradient(circle,rgba(243,181,27,0.25),transparent_65%)]" />

          {/* LOADER */}
          <AnimatePresence>
            {!ready && (
              <motion.div
                key="loader"
                initial={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.5 }}
                className="absolute inset-0 z-30 grid place-items-center bg-[#151515]"
              >
                <div className="w-[180px]">
                  <div className="h-[2px] w-full bg-white/10 overflow-hidden rounded">
                    <div
                      className="h-full bg-accent transition-[width] duration-200"
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                  <p className="mt-3 text-center text-[10px] uppercase tracking-[0.13em] text-white/50">
                    Loading {percent}%
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* TOP BAR: number + label */}
          <div className="absolute left-6 right-6 top-6 md:left-9 md:right-9 md:top-8 z-10 flex items-start justify-between">
            <span className="text-[10px] text-white/60 tracking-[0.12em]">
              {current.n} / 06
            </span>
            <span className="text-[9px] uppercase tracking-[0.12em] text-white/40">
              {active === 0
                ? "Start"
                : active === journey.length - 1
                ? "Result"
                : "Next"}
            </span>
          </div>

          {/* ACTIVE CARD CONTENT */}
          <div className="absolute left-6 right-6 bottom-8 md:left-9 md:right-9 md:bottom-10 z-10 flex items-end justify-between gap-6">
            <AnimatePresence mode="wait">
              <motion.div
                key={current.title}
                initial={{ opacity: 0, y: 24, filter: "blur(8px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                exit={{ opacity: 0, y: -16, filter: "blur(6px)" }}
                transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
              >
                <h3 className="text-[40px] sm:text-[56px] md:text-[72px] leading-none tracking-[-0.04em] text-white">
                  {current.title}
                </h3>
                <p className="mt-3 text-white/70 text-[13px] md:text-[15px] leading-[1.6] max-w-[340px]">
                  {current.text}
                </p>
              </motion.div>
            </AnimatePresence>

            <AnimatePresence mode="wait">
              <motion.div
                key={`icon-${current.title}`}
                initial={{ opacity: 0, scale: 0.7, rotate: -10 }}
                animate={{ opacity: 1, scale: 1, rotate: 0 }}
                exit={{ opacity: 0, scale: 0.7 }}
                transition={{ duration: 0.4 }}
                className="shrink-0 w-[68px] h-[68px] md:w-[84px] md:h-[84px] rounded-[18px] border border-white/20 grid place-items-center bg-white/10 backdrop-blur-md text-white"
              >
                <Icon size={32} strokeWidth={1.5} />
              </motion.div>
            </AnimatePresence>
          </div>

          {/* PROGRESS DOTS */}
          <div className="absolute right-4 md:right-7 top-1/2 -translate-y-1/2 z-10 flex flex-col gap-3">
            {journey.map((j, i) => (
              <div key={j.n} className="flex items-center gap-2 justify-end">
                <span
                  className={`hidden md:block text-[9px] tracking-[0.12em] uppercase transition-opacity duration-300 ${
                    i === active ? "opacity-100 text-white" : "opacity-0"
                  }`}
                >
                  {j.title}
                </span>
                <span
                  className="block rounded-full transition-all duration-300"
                  style={{
                    width: i === active ? 10 : 6,
                    height: i === active ? 10 : 6,
                    background: i === active ? "#F3B51B" : "rgba(255,255,255,0.3)",
                  }}
                />
              </div>
            ))}
          </div>

          {/* PROGRESS BAR (bottom) */}
          <motion.div
            className="absolute left-0 bottom-0 h-[2px] w-full origin-left bg-accent z-20"
            style={{ scaleX: smooth }}
          />
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* SECTION                                                             */
/* ------------------------------------------------------------------ */

export default function JourneySection() {
  return (
    // NOTE: overflow-x-clip (NOT overflow-hidden) — overflow-hidden breaks position: sticky
    <section
      id="journey"
      className="relative overflow-x-clip pt-[100px] md:pt-[145px] pb-[100px] md:pb-[145px] px-[5vw] md:px-[6vw] bg-bg"
    >
      {/* Background glow */}
      <motion.div
        className="pointer-events-none absolute right-[-250px] top-[10%] w-[600px] h-[600px] rounded-full bg-[radial-gradient(circle,rgba(243,181,27,0.08),transparent_68%)]"
        animate={{ scale: [1, 1.1, 1], opacity: [0.5, 0.8, 0.5] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
      />

      <div className="relative z-10">
        {/* HEADER */}
        <Reveal>
          <div className="flex items-center gap-2.5 text-[10px] uppercase tracking-[0.13em] font-bold text-gray-500 mb-5">
            <motion.span
              initial={{ width: 0 }}
              whileInView={{ width: 18 }}
              viewport={{ once: false }}
              transition={{ duration: 0.6 }}
              className="h-0.5 bg-accent block shrink-0"
            />
            The solution journey
          </div>
        </Reveal>

        {/* HEADING */}
        <h2 className="text-[clamp(40px,5vw,72px)] leading-[0.98] tracking-[-0.04em] font-normal max-w-[950px]">
          <AnimatedWords text="We build your digital system." delay={0.05} />
          <br />
          <span className="text-gray-400">
            <AnimatedWords text="Step by step." delay={0.3} />
          </span>
        </h2>

        {/* INTRO */}
        <Reveal delay={0.15}>
          <p className="mt-7 text-gray-500 text-[15px] sm:text-base leading-[1.7] max-w-[540px]">
            You don't need to change everything at once. We build the right
            pieces, connect them together, and improve them as your business
            grows.
          </p>
        </Reveal>

        {/* SCROLL-SCRUBBED FRAME STAGE */}
        <FrameStage />

        {/* BOTTOM STATEMENT */}
        <Reveal delay={0.2}>
          <div className="mt-16 md:mt-24 flex flex-col md:flex-row md:items-center justify-between gap-6 border-t border-black/10 pt-7">
            <p className="text-[13px] text-gray-500 max-w-[430px] leading-[1.6]">
              One connected system. Built around how your business actually
              works.
            </p>

            <motion.a
              href="#needs"
              whileHover={{ y: -3 }}
              className="inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.12em] font-bold"
            >
              Find your solution
              <ArrowRight size={14} />
            </motion.a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}