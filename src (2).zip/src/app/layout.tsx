import type { Metadata } from "next";
import "./globals.css";
import { ToastProvider } from "@/components/Toast";
import SmoothScroll from "@/components/SmoothScroll";


export const metadata: Metadata = {
  title: "Ozmo",
  description: "Digital solutions built around your business",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <SmoothScroll />
        <ToastProvider>{children}</ToastProvider>
      </body>
    </html>
  );
}