"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Globe2, Workflow, Bot, Link2, BarChart3, Rocket } from "lucide-react";

const journey = [
  { n: "01", title: "Build", text: "We create the website, app or platform your business needs.", Icon: Globe2, img: "/images/journey/build.jpg" },
  { n: "02", title: "Automate", text: "Repetitive tasks become automated workflows.", Icon: Workflow, img: "/images/journey/automate.jpg" },
  { n: "03", title: "AI", text: "AI helps your team respond, understand and work faster.", Icon: Bot, img: "/images/journey/ai.jpg" },
  { n: "04", title: "Integrate", text: "Your tools work together instead of working separately.", Icon: Link2, img: "/images/journey/integrate.jpg" },
  { n: "05", title: "Understand", text: "Turn your business data into simple, useful dashboards.", Icon: BarChart3, img: "/images/journey/understand.jpg" },
  { n: "06", title: "Grow", text: "Improve your digital presence and turn more visitors into customers.", Icon: Rocket, img: "/images/journey/grow.jpg" },
];

function Reveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { amount: 0.15, margin: "0px 0px -80px 0px", once: false });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 28 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 28 }}
      transition={{ duration: 0.7, delay: inView ? delay : 0, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

export default function JourneySection() {
  return (
    <section id="journey" className="py-[90px] md:py-[125px] px-[5vw] md:px-[6vw] bg-bg">
      <Reveal>
        <div className="flex items-center gap-2.5 text-[10px] uppercase tracking-[0.13em] font-bold text-gray-500 mb-5">
          <span className="w-4.5 h-0.5 bg-accent block" />
          The solution journey
        </div>
        <h2 className="text-[clamp(40px,5vw,72px)] leading-none tracking-tight font-normal">
          We build your digital system.<br />
          <em className="not-italic text-gray-500">Step by step.</em>
        </h2>
      </Reveal>

      <div id="solutions" className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3.5 mt-16">
        {journey.map(({ n, title, text, Icon, img }, i) => (
          <Reveal key={title} delay={i * 0.05}>
            <article className="group relative isolate overflow-hidden min-h-[310px] rounded-[20px] border border-line p-7 bg-[#1a1a1a] transition-[transform,box-shadow] duration-400 hover:-translate-y-1.5 hover:shadow-[0_25px_55px_rgba(0,0,0,0.22)]">
              {/* Background photo */}
              <div
                className="absolute inset-0 bg-cover bg-center scale-[1.04] transition-transform duration-600 group-hover:scale-110"
                style={{ backgroundImage: `url(${img})` }}
              />
              {/* Readability overlay */}
              <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(10,10,10,0.55)_0%,rgba(10,10,10,0.55)_55%,rgba(10,10,10,0.88)_100%)]" />
              {/* Decorative glow */}
              <div className="absolute w-[190px] h-[190px] -right-20 -bottom-20 rounded-full bg-[radial-gradient(circle,rgba(243,181,27,0.22),transparent_65%)] transition-transform duration-500 group-hover:scale-130" />

              <span className="relative z-2 text-[10px] text-white/65 tracking-[0.08em]">{n}</span>
              <h3 className="relative z-2 text-[30px] mt-3.5 mb-2.5 tracking-tight text-white">{title}</h3>
              <p className="relative z-2 text-white/80 text-[13px] leading-[1.55] max-w-[260px]">{text}</p>

              <div className="absolute right-6 bottom-6 z-2 w-[74px] h-[74px] rounded-[18px] border border-white/25 grid place-items-center bg-white/10 backdrop-blur-md text-white transition-[transform,background] duration-350 group-hover:-rotate-6 group-hover:scale-106 group-hover:bg-white/18">
                <Icon size={30} />
              </div>
            </article>
          </Reveal>
        ))}
      </div>
    </section>
  );
}