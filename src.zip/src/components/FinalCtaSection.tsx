"use client";

import { useState } from "react";
import { ArrowRight } from "lucide-react";
import ContactModal from "./ContactModal";

export default function FinalCtaSection() {
  const [modalOpen, setModalOpen] = useState(false);

  return (
    <section id="contact" className="relative overflow-hidden min-h-[70vh] md:min-h-[80vh] py-[100px] md:py-[150px] px-[5vw] md:px-[6vw] flex flex-col items-center justify-center text-center bg-[radial-gradient(circle_at_50%_50%,rgba(243,181,27,0.08),transparent_40%),#f0f0eb]">
      <div className="absolute w-[500px] h-[500px] rounded-full bg-accent blur-[110px] opacity-[0.12] -right-[170px] -top-[170px]" />

      <div className="relative z-1 flex items-center gap-2.5 text-[10px] uppercase tracking-[0.13em] font-bold text-gray-500 mb-5">
        <span className="w-4.5 h-0.5 bg-accent block" />
        Start with the problem
      </div>

      <h2 className="relative z-1 text-[48px] md:text-[clamp(48px,7vw,100px)] leading-[0.95] tracking-tight">
        Your business is ready<br />
        for its <em className="not-italic text-gray-500">next step.</em>
      </h2>

      <p className="relative z-1 text-gray-600 leading-relaxed my-7">
        Tell us what&apos;s slowing your business down.<br />
        We&apos;ll help you find the digital solution.
      </p>

      <button
        onClick={() => setModalOpen(true)}
        className="relative z-1 inline-flex items-center gap-2.5 rounded-full text-xs font-bold px-5 py-4 bg-black text-white hover:-translate-y-0.5 transition"
      >
        Let&apos;s Talk About Your Business <ArrowRight size={18} />
      </button>

      <small className="relative z-1 mt-4.5 text-gray-400 text-[10px]">No pressure. No complicated tech talk.</small>

      <ContactModal open={modalOpen} onClose={() => setModalOpen(false)} />
    </section>
  );
}