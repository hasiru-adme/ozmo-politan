"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import {
  Globe2,
  Zap,
  Bot,
  BarChart3,
  ArrowUpRight,
} from "lucide-react";

const needs = [
  {
    number: "01",
    title: "Get online",
    problem: "Your business needs a stronger digital presence.",
    solution: "Website · E-commerce · Landing page",
    Icon: Globe2,
  },
  {
    number: "02",
    title: "Save time",
    problem: "Too much manual work is slowing your business down.",
    solution: "Automation · Integrations · Workflows",
    Icon: Zap,
  },
  {
    number: "03",
    title: "Use AI",
    problem: "You know AI can help, but don't know where to start.",
    solution: "AI assistants · Support · Smart tools",
    Icon: Bot,
  },
  {
    number: "04",
    title: "Grow",
    problem: "You need more leads, visibility and measurable results.",
    solution: "SEO · Analytics · Lead generation",
    Icon: BarChart3,
  },
];

function Reveal({
  children,
  delay = 0,
}: {
  children: React.ReactNode;
  delay?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);

  const inView = useInView(ref, {
    amount: 0.15,
    margin: "0px 0px -80px 0px",
    once: false,
  });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 35 }}
      animate={
        inView
          ? { opacity: 1, y: 0 }
          : { opacity: 0, y: 35 }
      }
      transition={{
        duration: 0.7,
        delay: inView ? delay : 0,
        ease: [0.22, 1, 0.36, 1],
      }}
    >
      {children}
    </motion.div>
  );
}

export default function NeedsSection() {
  return (
    <section
      id="needs"
      className="relative overflow-hidden bg-white px-[5vw] py-[100px] md:px-[6vw] md:py-[140px]"
    >
      {/* Subtle background detail */}
      <div className="pointer-events-none absolute left-1/2 top-0 h-[500px] w-[500px] -translate-x-1/2 rounded-full bg-[#f7f7f2] opacity-60 blur-3xl" />

      <div className="relative z-10">
        {/* Header */}
        <Reveal>
          <div className="mb-5 flex items-center gap-2.5 text-[10px] font-bold uppercase tracking-[0.14em] text-gray-500">
            <span className="block h-[2px] w-5 bg-accent" />
            What does your business need?
          </div>

          <div className="max-w-[900px]">
            <h2 className="text-[clamp(40px,5vw,72px)] font-normal leading-[0.98] tracking-[-0.04em] text-gray-900">
              You don&apos;t need more technology.
              <br />
              <span className="text-gray-400">
                You need the right solution.
              </span>
            </h2>
          </div>
        </Reveal>

        {/* Cards */}
        <div className="mt-20 grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
          {needs.map(
            (
              {
                number,
                title,
                problem,
                solution,
                Icon,
              },
              i
            ) => (
              <Reveal key={number} delay={i * 0.08}>
                <a
                  href="#contact"
                  className="
                    group relative flex min-h-[390px]
                    flex-col overflow-hidden
                    rounded-[28px]
                    border border-gray-200
                    bg-[#fafaf8]
                    p-7
                    transition-all
                    duration-500
                    hover:-translate-y-2
                    hover:border-[#101828]
                    hover:bg-gray-900
                    hover:shadow-[0_30px_70px_rgba(0,0,0,0.12)]
                  "
                >
                  {/* Top */}
                  <div className="flex items-start justify-between">
                    <span
                      className="
                        text-[12px]
                        font-medium
                        tracking-[0.08em]
                        text-gray-400
                        transition-colors
                        duration-500
                        group-hover:text-gray-500
                      "
                    >
                      
                    </span>

                    <div
                      className="
                        flex h-12 w-12
                        items-center justify-center
                        rounded-full
                        border border-gray-200
                        bg-white
                        transition-all
                        duration-500
                        group-hover:rotate-[-10deg]
                        group-hover:border-white/20
                        group-hover:bg-white/10
                      "
                    >
                      <Icon
                        size={21}
                        strokeWidth={1.7}
                        className="
                          text-gray-700
                          transition-colors
                          duration-500
                          group-hover:text-white
                        "
                      />
                    </div>
                  </div>

                  {/* Decorative line */}
                  <div className="mt-10 h-px w-full bg-gray-200 transition-colors duration-500 group-hover:bg-white/10" />

                  {/* Content */}
                  <div className="mt-8">
                    <h3
                      className="
                        text-[30px]
                        font-medium
                        leading-none
                        tracking-[-0.04em]
                        text-gray-900
                        transition-colors
                        duration-500
                        group-hover:text-white
                      "
                    >
                      {title}
                    </h3>

                    <p
                      className="
                        mt-5
                        max-w-[240px]
                        text-[13px]
                        leading-[1.6]
                        text-gray-500
                        transition-colors
                        duration-500
                        group-hover:text-gray-400
                      "
                    >
                      {problem}
                    </p>
                  </div>

                  {/* Bottom */}
                  <div className="mt-auto">
                    <div
                      className="
                        mb-5
                        text-[11px]
                        font-medium
                        uppercase
                        tracking-[0.08em]
                        text-gray-400
                        transition-colors
                        duration-500
                        group-hover:text-gray-500
                      "
                    >
                      {solution}
                    </div>

                    <div
                      className="
                        flex items-center justify-between
                        border-t
                        border-gray-200
                        pt-5
                        transition-colors
                        duration-500
                        group-hover:border-white/10
                      "
                    >
                      <span
                        className="
                          text-[11px]
                          font-bold
                          uppercase
                          tracking-[0.12em]
                          text-gray-700
                          transition-colors
                          duration-500
                          group-hover:text-white
                        "
                      >
                        Explore solution
                      </span>

                      <span
                        className="
                          flex h-9 w-9
                          items-center justify-center
                          rounded-full
                          border border-gray-200
                          bg-white
                          transition-all
                          duration-500
                          group-hover:-translate-y-1
                          group-hover:translate-x-1
                          group-hover:border-white
                        "
                      >
                        <ArrowUpRight
                          size={16}
                          className="
                            text-gray-700
                            transition-colors
                            duration-500
                            group-hover:text-gray-900
                          "
                        />
                      </span>
                    </div>
                  </div>

                  {/* Hover glow */}
                  <div
                    className="
                      pointer-events-none
                      absolute
                      -bottom-24
                      -right-24
                      h-48
                      w-48
                      rounded-full
                      bg-white/[0.04]
                      blur-2xl
                      transition-all
                      duration-700
                      group-hover:scale-150
                    "
                  />
                </a>
              </Reveal>
            )
          )}
        </div>
      </div>
    </section>
  );
}