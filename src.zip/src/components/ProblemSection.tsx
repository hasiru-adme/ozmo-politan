"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Users, Mail, X, Settings2, BarChart3, ArrowUpRight } from "lucide-react";

const problems = [
  { label: "Too many enquiries", Icon: Users, img: "/images/problems/enquiries.jpg", bg: "bg-blue", ink: "text-blue-ink" },
  { label: "Manual follow-ups", Icon: Mail, img: "/images/problems/followups.jpg", bg: "bg-orange", ink: "text-orange-ink" },
  { label: "Missed customers", Icon: X, img: "/images/problems/missed.jpg", bg: "bg-red", ink: "text-red-ink" },
  { label: "Too much admin", Icon: Settings2, img: "/images/problems/admin.jpg", bg: "bg-purple", ink: "text-purple-ink" },
  { label: "No clear data", Icon: BarChart3, img: "/images/problems/data.jpg", bg: "bg-green", ink: "text-green-ink" },
  { label: "Slow growth", Icon: ArrowUpRight, img: "/images/problems/growth.jpg", bg: "bg-teal", ink: "text-teal-ink" },
];

function Reveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { amount: 0.15, margin: "0px 0px -80px 0px", once: false });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 28 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 28 }}
      transition={{ duration: 0.7, delay: inView ? delay : 0, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

export default function ProblemSection() {
  return (
    <section id="problem" className="py-[90px] md:py-[125px] px-[5vw] md:px-[6vw] bg-white">
      <Reveal>
        <div className="flex items-center gap-2.5 text-[10px] uppercase tracking-[0.13em] font-bold text-gray-500 mb-5">
          <span className="w-4.5 h-0.5 bg-accent block" />
          The problem
        </div>
        <h2 className="text-[clamp(40px,5vw,72px)] leading-none tracking-tight font-normal">
          Running a business<br />
          <em className="not-italic text-gray-500">is already complicated.</em>
        </h2>
      </Reveal>

      <div className="grid grid-cols-1 md:grid-cols-3 xl:grid-cols-6 gap-4 md:gap-5 mt-16">
        {problems.map(({ label, Icon, img, bg, ink }, i) => (
          <Reveal key={label} delay={i * 0.05}>
            <div
              className="group relative isolate overflow-hidden min-h-[145px] md:min-h-[180px] border border-line rounded-[18px] p-5 md:p-5.5 flex flex-col justify-between bg-white will-change-transform transition-all duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] hover:-translate-y-2 hover:border-[#d3d3ce] hover:shadow-[0_24px_48px_rgba(0,0,0,0.08)]"
            >
              {/* Decorative circle with background image, faded */}
              <div
                className="absolute w-[115px] h-[115px] -right-[22px] top-8 rounded-full border border-black/[0.08] -z-10 opacity-[0.38] grayscale-[0.8] bg-cover bg-center transform-gpu will-change-transform transition-[transform,opacity,filter] duration-[900ms] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.1] group-hover:rotate-3 group-hover:opacity-100 group-hover:grayscale-[0.7]"
                style={{ backgroundImage: `url(${img})` }}
              />

              <Icon
                size={22}
                className={`w-[43px] h-[43px] p-2.5 rounded-[13px] ${bg} ${ink} will-change-transform transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-110`}
                strokeWidth={1.8}
              />

              <b className="relative z-2 text-[13px] leading-[1.35] max-w-[145px] font-bold">{label}</b>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}