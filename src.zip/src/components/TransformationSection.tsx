"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { X, Check, ArrowRight } from "lucide-react";

const before = ["Website", "Phone", "Email", "Excel", "Manual work", "Disconnected tools", "Guesswork"];
const after = ["Website", "AI", "Automation", "CRM", "Data", "Growth"];

function Reveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { amount: 0.15, margin: "0px 0px -80px 0px", once: false });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 28 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 28 }}
      transition={{ duration: 0.7, delay: inView ? delay : 0, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

export default function TransformationSection() {
  return (
    <section className="py-[90px] md:py-[125px] px-[5vw] md:px-[6vw] bg-[#111] text-white">
      <Reveal>
        <div className="flex items-center gap-2.5 text-[10px] uppercase tracking-[0.13em] font-bold text-gray-400 mb-5">
          <span className="w-4.5 h-0.5 bg-accent block" />
          The transformation
        </div>
        <h2 className="text-[clamp(40px,5vw,72px)] leading-none tracking-tight font-normal">
          From disconnected tools<br />
          <em className="not-italic text-gray-500">to one connected business.</em>
        </h2>
      </Reveal>

      <div className="grid grid-cols-1 md:grid-cols-[1fr_280px_1fr] gap-9 items-center mt-16">
        {/* Before card */}
        <Reveal delay={0}>
          <div className="relative overflow-hidden border border-[#333] rounded-[22px] p-7 bg-[linear-gradient(145deg,rgba(255,255,255,0.03),transparent)]">
            <div className="absolute w-[170px] h-[170px] -right-[90px] -top-[90px] rounded-full border border-[#333]" />
            <span className="block text-lg font-bold mb-5">Before</span>
            {before.map((x) => (
              <div key={x} className="flex items-center gap-2.5 py-2.5 border-b border-[#262626] text-gray-400 text-[13px] last:border-0">
                <X size={14} className="text-gray-500" />
                {x}
              </div>
            ))}
          </div>
        </Reveal>

        {/* Connector */}
        <div className="flex flex-col items-center gap-4 rotate-90 md:rotate-0 h-[140px] md:h-auto">
          <div className="w-[100px] h-20 border-2 border-[#555] rounded-[60%_40%_50%_30%] -rotate-[15deg] opacity-70" />
          <span className="text-[13px] tracking-[0.08em] font-extrabold text-center">
            ONE DIGITAL<br />SYSTEM
          </span>
          <ArrowRight size={28} />
        </div>

        {/* After card */}
        <Reveal delay={0.05}>
          <div className="relative overflow-hidden border border-[#333] rounded-[22px] p-7 bg-[linear-gradient(145deg,rgba(255,255,255,0.03),transparent)]">
            <div className="absolute w-[170px] h-[170px] -right-[90px] -top-[90px] rounded-full border border-[#333]" />
            <span className="block text-lg font-bold mb-5">After</span>
            {after.map((x) => (
              <div key={x} className="flex items-center gap-2.5 py-2.5 border-b border-[#262626] text-gray-400 text-[13px] last:border-0">
                <Check size={14} className="text-accent" />
                {x}
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}