"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Sparkles } from "lucide-react";

export default function QuestionSection() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { amount: 0.15, margin: "0px 0px -80px 0px", once: false });

  return (
    <section className="py-[100px] md:py-[150px] px-[5vw] md:px-[6vw] text-center bg-[radial-gradient(circle_at_50%_20%,rgba(243,181,27,0.08),transparent_35%),#f0f0eb]">
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 28 }}
        animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 28 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      >
        <div className="w-[54px] h-[54px] rounded-full bg-accent grid place-items-center mx-auto mb-7 shadow-[0_15px_30px_rgba(243,181,27,0.2)]">
          <Sparkles size={23} />
        </div>
        <h2 className="text-[38px] md:text-[clamp(36px,5vw,68px)] leading-[1.03] tracking-tight">
          What if your business could<br />handle more of it automatically?
        </h2>
        <p className="text-gray-500 mt-4">We can help.</p>
      </motion.div>
    </section>
  );
}