export default function SiteFooter() {
  return (
    <footer className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4.5 py-7.5 px-[5vw] md:px-[6vw] bg-[#111] text-gray-400 text-[10px]">
      <div className="flex items-center gap-2.5 text-white">
        <span className="w-2.5 h-2.5 bg-accent rounded-full block" />
        <span>
          <b className="block">YOUR BRAND</b>
          <small className="block text-gray-400 mt-1">Digital Solutions</small>
        </span>
      </div>
      <p className="m-0">We simplify the way your business works.</p>
      <div>© 2026 Your Brand</div>
    </footer>
  );
}