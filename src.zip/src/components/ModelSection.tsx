"use client";

import { ArrowRight } from "lucide-react";

const steps = ["BUILD", "LAUNCH", "3 MONTHS FREE SUPPORT", "MONTHLY MANAGED SERVICE", "CONTINUOUS IMPROVEMENT"];

export default function ModelSection() {
  return (
    <section className="py-[85px] md:py-[110px] px-[5vw] md:px-[6vw] bg-[#f0f0eb] grid grid-cols-1 md:grid-cols-[0.8fr_1.2fr] gap-10 md:gap-[8vw] items-center">
      <div>
        <div className="flex items-center gap-2.5 text-[10px] uppercase tracking-[0.13em] font-bold text-gray-500 mb-5">
          <span className="w-4.5 h-0.5 bg-accent block" />
          Our model
        </div>
        <h2 className="text-[clamp(38px,4vw,60px)] leading-none tracking-tight mb-6">
          No big technology bill.<br />
          <em className="not-italic text-gray-500">One simple monthly relationship.</em>
        </h2>
        <p className="max-w-[520px] text-gray-600 text-sm leading-[1.65] mb-7">
          Instead of paying for everything upfront and being left to manage it yourself, we build, host, maintain and improve your digital solution with you.
        </p>
        <a href="#contact" className="inline-flex items-center gap-2.5 rounded-full text-xs font-bold px-5 py-4 bg-accent shadow-[0_10px_25px_rgba(243,181,27,0.18)] hover:bg-[#e9aa0e] hover:-translate-y-0.5 transition">
          See Your Monthly Plan <ArrowRight size={17} />
        </a>
      </div>

      <div className="relative grid grid-cols-2 md:grid-cols-5 gap-5 md:gap-1.5 items-start mt-5 md:mt-0">
        <div className="hidden md:block absolute top-[27px] left-[10%] right-[10%] h-px bg-[#d4d4ce]" />
        {steps.map((x, i) => (
          <div key={x} className="relative text-center z-2">
            <div className="w-[54px] h-[54px] rounded-full bg-white grid place-items-center mx-auto mb-3.5 font-extrabold border border-[#deded8]">
              {i + 1}
            </div>
            <b className="text-[9px] leading-[1.3] block">{x}</b>
          </div>
        ))}
      </div>
    </section>
  );
}