"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Code2, Settings2, Sparkles, Rocket, ArrowUpRight } from "lucide-react";

const why = [
  { number: "01", t: "Build", d: "We create your digital foundation.", Icon: Code2 },
  { number: "02", t: "Manage", d: "We keep everything running.", Icon: Settings2 },
  { number: "03", t: "Improve", d: "We continuously improve your system.", Icon: Sparkles },
  { number: "04", t: "Grow", d: "We help your digital presence generate more value.", Icon: Rocket },
];

function Reveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { amount: 0.15, margin: "0px 0px -80px 0px", once: false });
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
      transition={{ duration: 0.7, delay: inView ? delay : 0, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

export default function WhySection() {
  return (
    <section id="why" className="relative overflow-hidden bg-bg px-[5vw] py-[100px] md:px-[6vw] md:py-[130px]">
      <div className="pointer-events-none absolute right-[-180px] top-[10%] h-[420px] w-[420px] rounded-full border border-black/[0.04]" />
      <div className="pointer-events-none absolute right-[-120px] top-[18%] h-[300px] w-[300px] rounded-full border border-black/[0.035]" />

      <div className="mx-auto max-w-[1500px]">
        <div className="grid gap-16 lg:grid-cols-[0.85fr_1.15fr] lg:gap-[8vw]">
          {/* LEFT */}
          <Reveal>
            <div className="lg:sticky lg:top-28">
              <div className="mb-6 flex items-center gap-2.5 text-[10px] font-bold uppercase tracking-[0.13em] text-gray-500">
                <span className="block h-[2px] w-5 bg-accent" />
                Why businesses choose us
              </div>

              <h2 className="max-w-[650px] text-[clamp(44px,5.5vw,82px)] font-normal leading-[0.94] tracking-[-0.045em]">
                One team.
                <br />
                <span className="text-gray-400">One relationship.</span>
              </h2>

              <p className="mt-8 max-w-[430px] text-sm leading-7 text-gray-500 md:text-base">
                Instead of managing multiple providers, you get one experienced team that can build, manage, improve and grow your digital presence.
              </p>

              <div className="mt-10 flex items-center gap-3 text-xs font-semibold">
                <span className="flex h-8 w-8 items-center justify-center rounded-full border border-line">↓</span>
                <span className="text-gray-500">One partner from start to scale</span>
              </div>
            </div>
          </Reveal>

          {/* RIGHT — 2x2 GRID */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {why.map(({ number, t, d, Icon }, i) => (
              <Reveal key={t} delay={i * 0.08}>
             <motion.div
  whileHover={{ y: -6 }}
  transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
  className="group relative flex min-h-[240px] flex-col justify-between overflow-hidden rounded-[24px] border border-line bg-white p-7 md:p-8 transition-colors duration-500 ease-out hover:border-accent">
                  {/* Number */}
                  <div className="flex items-start justify-between">
                    <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#f3f3ee] text-gray-700">
                      <Icon size={23} strokeWidth={1.8} />
                    </div>
                    <span className="text-[11px] font-medium tracking-[0.15em] text-gray-300">{number}</span>
                  </div>

                  {/* Content */}
                  <div>
                    <div className="mb-3 h-px w-8 bg-gray-200 transition-all duration-500 group-hover:w-14" />
                    <h3 className="text-2xl tracking-tight">{t}</h3>
                    <p className="mt-2 max-w-[260px] text-xs leading-6 text-gray-500">{d}</p>
                  </div>

                  {/* Hover arrow */}
                  <div className="absolute bottom-7 right-7 flex h-9 w-9 translate-y-2 items-center justify-center rounded-full border border-line opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100">
                    <ArrowUpRight size={16} />
                  </div>

                  {/* Decorative circle */}
                  <div className="pointer-events-none absolute -right-20 -top-20 h-40 w-40 rounded-full bg-[#f7f7f2] transition-transform duration-700 group-hover:scale-125" />
                </motion.div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}