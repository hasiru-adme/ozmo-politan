"use client";

import { AnimatePresence, motion } from "framer-motion";
import Image from "next/image";
import { useEffect, useState } from "react";

const images = [
    "/images/hero/hero-visual.jpeg",
    "/images/hero/hero-visual-1.jpeg",
    "/images/hero/hero-visual-2.jpeg",
    "/images/hero/hero-visual-3.jpeg",

];

const INTERVAL_MS = 4000;

export default function HeroImageSlider() {
    const [index, setIndex] = useState(0);

    useEffect(() => {
        const timer = setInterval(() => {
            setIndex((i) => (i + 1) % images.length);
        }, INTERVAL_MS);
        return () => clearInterval(timer);
    }, []);

    return (
        <div className="h-full rounded-[20px] md:rounded-[28px] overflow-hidden relative shadow-[0_35px_80px_rgba(0,0,0,0.08)]">
            <AnimatePresence mode="sync">
                <motion.div
                    key={index}
                    className="absolute inset-0"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 1.2, ease: "easeInOut" }}
                >
                    <Image
                        src={images[index]}
                        alt="Professional working with connected digital tools"
                        fill
                        priority={index === 0}
                        className="object-cover"
                        sizes="(max-width: 768px) 100vw, 50vw"
                    />
                </motion.div>
            </AnimatePresence>

            {/* Dots indicator */}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10 flex gap-1.5">
                {images.map((_, i) => (
                    <button
                        key={i}
                        onClick={() => setIndex(i)}
                        aria-label={`Go to slide ${i + 1}`}
                        className={`h-1.5 rounded-full transition-all duration-300 ${i === index ? "w-5 bg-white" : "w-1.5 bg-white/50"
                            }`}
                    />
                ))}
            </div>
        </div>
    );
}