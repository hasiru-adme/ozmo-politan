"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { MessageSquare, Users, Sparkles, Code2, Settings2, Rocket } from "lucide-react";

const flow = [
  { label: "You tell us the problem.", Icon: MessageSquare },
  { label: "We understand your business.", Icon: Users },
  { label: "We design the right solution.", Icon: Sparkles },
  { label: "We build it.", Icon: Code2 },
  { label: "We manage it.", Icon: Settings2 },
  { label: "We help it grow.", Icon: Rocket },
];

function Reveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { amount: 0.15, margin: "0px 0px -80px 0px", once: false });
  return (
    <motion.div ref={ref} initial={{ opacity: 0, y: 28 }} animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 28 }} transition={{ duration: 0.7, delay: inView ? delay : 0, ease: [0.22, 1, 0.36, 1] }}>
      {children}
    </motion.div>
  );
}

export default function HowSection() {
  return (
    <section id="how" className="py-[90px] md:py-[125px] px-[5vw] md:px-[6vw] bg-bg">
      <Reveal>
        <div className="flex items-center gap-2.5 text-[10px] uppercase tracking-[0.13em] font-bold text-gray-500 mb-5">
          <span className="w-4.5 h-0.5 bg-accent block" />
          How we work
        </div>
        <h2 className="text-[clamp(40px,5vw,72px)] leading-none tracking-tight font-normal">
          We make it simple<br />
          <em className="not-italic text-gray-500">for you.</em>
        </h2>
      </Reveal>

      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3.5 mt-16">
        {flow.map(({ label, Icon }, i) => (
          <Reveal key={label} delay={i * 0.05}>
            <div className="relative text-center [&:not(:last-child)::after]:content-[''] [&:not(:last-child)::after]:absolute [&:not(:last-child)::after]:top-[31px] [&:not(:last-child)::after]:-right-[15px] [&:not(:last-child)::after]:w-7 [&:not(:last-child)::after]:border-t [&:not(:last-child)::after]:border-dashed [&:not(:last-child)::after]:border-[#d4d4ce] max-md:[&::after]:hidden">
              <div className="group w-16 h-16 mx-auto mb-4 rounded-full border border-[#d7d7d2] grid place-items-center bg-white transition-[transform,background,border-color] duration-300 hover:-translate-y-1.5 hover:bg-[#fff9e7] hover:border-[#ead89e]">
                <Icon size={22} />
              </div>
              <b className="block text-[11px] leading-[1.4] text-gray-600 font-bold">{label}</b>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}