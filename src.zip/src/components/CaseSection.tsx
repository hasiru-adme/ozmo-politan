"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Globe2, MessageSquare, Database, Bot, Phone, CalendarDays, Mail, Code2, Check, CircleCheck } from "lucide-react";

const caseSteps = [
  { text: "A customer visits your website.", Icon: Globe2, img: "/images/case/website.jpg", tint: "#dfeaf5", tintInk: "#46627b" },
  { text: "They request a quote.", Icon: MessageSquare, img: "/images/case/quote.jpg", tint: "#f5e7d7", tintInk: "#9b673b" },
  { text: "The request is automatically captured.", Icon: Database, img: "/images/case/captured.jpg", tint: "#f2dfdf", tintInk: "#985959" },
  { text: "AI helps qualify the enquiry.", Icon: Bot, img: "/images/case/ai.jpg", tint: "#e8e2f1", tintInk: "#6d5b82" },
  { text: "Your team gets notified.", Icon: Phone, img: "/images/case/notified.jpg", tint: "#dfeadf", tintInk: "#557255" },
  { text: "Customer books a time.", Icon: CalendarDays, img: "/images/case/booking.jpg", tint: "#dceaea", tintInk: "#4f7070" },
  { text: "Reminder is sent automatically.", Icon: Mail, img: "/images/case/reminder.jpg", tint: "#dfeaf5", tintInk: "#46627b" },
  { text: "Invoice is created.", Icon: Code2, img: "/images/case/invoice.jpg", tint: "#f5e7d7", tintInk: "#9b673b" },
  { text: "Payment is received.", Icon: Check, img: "/images/case/payment.jpg", tint: "#f2dfdf", tintInk: "#985959" },
  { text: "Customer gets a review request.", Icon: CircleCheck, img: "/images/case/review.jpg", tint: "#dfeadf", tintInk: "#557255" },
];

function Reveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { amount: 0.15, margin: "0px 0px -80px 0px", once: false });
  return (
    <motion.div ref={ref} initial={{ opacity: 0, y: 28 }} animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 28 }} transition={{ duration: 0.7, delay: inView ? delay : 0, ease: [0.22, 1, 0.36, 1] }}>
      {children}
    </motion.div>
  );
}

export default function CaseSection() {
  return (
    <section className="py-[90px] md:py-[125px] px-[5vw] md:px-[6vw] bg-white">
      <Reveal>
        <div className="flex items-center gap-2.5 text-[10px] uppercase tracking-[0.13em] font-bold text-gray-500 mb-5">
          <span className="w-4.5 h-0.5 bg-accent block" />
          Real-life example
        </div>
        <h2 className="text-[clamp(40px,5vw,72px)] leading-none tracking-tight font-normal">
          Imagine you run<br />
          <em className="not-italic text-gray-500">a cleaning business.</em>
        </h2>
      </Reveal>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 border-t border-b border-line mt-16">
        {caseSteps.map(({ text, Icon, img, tint, tintInk }, i) => (
          <Reveal key={text} delay={i * 0.025}>
            <div
              className="group relative isolate overflow-hidden flex flex-col items-center justify-end text-center gap-2.5 min-h-[170px] p-5 border-r border-b md:border-b-0 border-line last:border-r-0 xl:[&:nth-child(5n)]:border-r-0 transition-colors duration-300"
              style={{ "--tint": tint, "--tint-ink": tintInk } as React.CSSProperties}
            >
              {/* photo layer */}
              <div
                className="absolute inset-0 -z-20 bg-cover bg-center scale-[1.02] opacity-[0.18] transition-[opacity,transform] duration-500 group-hover:opacity-100 group-hover:scale-100"
                style={{ backgroundImage: `url(${img})` }}
              />
              {/* tint layer — sits between photo and white gradient, fades in on hover */}
              <div
                className="absolute inset-0 -z-[11] opacity-0 transition-opacity duration-300 group-hover:opacity-40"
                style={{ backgroundColor: tint }}
              />
              {/* white readability gradient */}
              <div className="absolute inset-0 -z-10 bg-[linear-gradient(180deg,rgba(255,255,255,0.4)_0%,rgba(255,255,255,0.55)_55%,rgba(255,255,255,0.92)_100%)] transition-opacity duration-300 group-hover:opacity-80" />

              <div
                className="w-11 h-11 rounded-full grid place-items-center transition-all duration-300 group-hover:opacity-0 group-hover:-translate-y-1.5 group-hover:scale-90"
                style={{ backgroundColor: "#f2f2ed" }}
              >
                <Icon size={19} style={{ color: "#555" }} className="transition-colors duration-300" />
              </div>
              <span
                className="text-sm leading-[1.4] max-w-[130px] font-semibold transition-colors duration-300"
                style={{ color: "#333" }}
              >
                {text}
              </span>

              {/* subtle bottom accent bar that grows in on hover, tinted per item */}
              <span
                className="absolute left-0 bottom-0 h-[3px] w-0 transition-all duration-300 group-hover:w-full"
                style={{ backgroundColor: tintInk }}
              />
            </div>
          </Reveal>
        ))}
      </div>

      <Reveal>
        <div className="text-center pt-[90px]">
          <p className="m-0 text-gray-500">That&apos;s not just a website.</p>
          <h2 className="text-[clamp(36px,5vw,66px)] mt-2">
            That&apos;s a <span className="text-accent-dark">digital business system.</span>
          </h2>
        </div>
      </Reveal>
    </section>
  );
}